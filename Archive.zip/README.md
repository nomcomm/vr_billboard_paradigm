Analysis for {authors blinded} (submitted)
=============================================

Data and analysis code for  *FINAL TITLE* [Temporary Google Doc](https://docs.google.com/document/d/1o3_6ttUq-PX0GNrQSC6rJg3D8XiYyKFzsP_giCv6PpI/edit?usp=sharing)


***

<img align="right" width=250px src=data/explainer_fig.png> 



### Code

-   The current notebooks to reproduce the analyses are in the scripts folder.


### Data

-   The raw data ...

### Dependencies

-   see environment file


2023 | X
